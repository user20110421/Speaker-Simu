/*********************************************************************
    ������: ����ģ����
    ��Ȩ: ����
    ����: yyh
    ����: 2023-09-02 07:31 
    ˵��: ����ģ����
*********************************************************************/
#include <iostream>
#include <string>
#include <windows.h>
using namespace std;
void play();
void start();

string s1="=                 =  ";
string s2="  =             =    ";
string s3="     =        =      ";
string s4="       =====         ";

void play(){
	s:
		cout<<"����1��һ�Σ�����2�ϵ磬����3ͨ�磺";
	char p;
	while(1){
		cin>>p;
		switch(p){
			case'1':{
				system("cls");
				s1="  ==               ==  ";
				s2="    ==           ==    ";
				s3="       = ===== =       ";
				cout<<s1<<"\n"
					<<s2<<"\n"
					<<s3<<"\n";
				Sleep(100);
				system("cls");
				s1="=                 =  ";
				s2="  =             =    ";
				s3="     =        =      ";
				s4="       =====         ";
				start();
				break;
			}
			case'2':
			case'3':{
				system("cls");
				s1="==               ==  ";
				s2="  ==           ==    ";
				s3="     = ===== =       ";
				cout<<s1<<"\n"
					<<s2<<"\n"
					<<s3<<"\n";
				Sleep(10);
				system("cls");
				s1="=                 =  ";
				s2="  =             =    ";
				s3="     =       =       ";
				s4="       =====         ";
				start();
				break;
			}
		}
	}
	
	
}

void start(){
	system("cls");
	cout<<s1<<"\n"
		<<s2<<"\n"
		<<s3<<"\n"
		<<s4<<"\n";
	play();
}

int main() {
	start();
	return 0;
} 

